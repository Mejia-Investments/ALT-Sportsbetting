
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Mail } from "lucide-react";
import { motion } from "framer-motion";

export default function AltSportsLandingPage() {
  return (
    <div className="min-h-screen bg-gray-950 text-white p-6 md:p-12">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="max-w-4xl mx-auto text-center"
      >
        <h1 className="text-4xl md:text-6xl font-bold mb-4 text-lime-400">
          AI Lead Engine for Alt Sports & Betting
        </h1>
        <p className="text-lg md:text-xl text-gray-300 mb-8">
          Get verified, high-intent fans & bettors for niche sports like F1, Surfing, MMA, and more — using AI, not ads.
        </p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3, duration: 0.6 }}
        className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto"
      >
        <Card className="bg-gray-900 border border-gray-800">
          <CardContent className="p-6">
            <h2 className="text-2xl font-semibold text-lime-300 mb-2">What You Get</h2>
            <ul className="list-disc pl-5 space-y-2 text-gray-300">
              <li>100 warm leads: real fans & bettors by sport</li>
              <li>Verified contact info (email/social)</li>
              <li>Data source links (Reddit, Discord, Twitter, etc.)</li>
              <li>Optional weekly delivery</li>
              <li>No bots. No fluff. Just results.</li>
            </ul>
          </CardContent>
        </Card>

        <Card className="bg-gray-900 border border-gray-800">
          <CardContent className="p-6">
            <h2 className="text-2xl font-semibold text-lime-300 mb-2">Starter Package</h2>
            <ul className="list-disc pl-5 space-y-2 text-gray-300">
              <li>$299 one-time</li>
              <li>Pay only if leads pass your filters</li>
              <li>Bonus: AI outreach templates included</li>
              <li>Upgrade anytime to weekly delivery ($499/mo)</li>
            </ul>
          </CardContent>
        </Card>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6, duration: 0.5 }}
        className="mt-12 text-center"
      >
        <h3 className="text-xl font-medium mb-4 text-gray-200">
          Ready to test the pilot? Zero risk.
        </h3>
        <div className="flex flex-col md:flex-row gap-4 justify-center">
          <Button className="bg-lime-500 text-black hover:bg-lime-400 text-lg px-6 py-3">
            Book a Discovery Call
          </Button>
          <Button variant="outline" className="text-white border-gray-600 text-lg px-6 py-3">
            <Mail className="mr-2 h-5 w-5" /> Mejia.invest2@gmail.com
          </Button>
        </div>
        <p className="mt-6 text-sm text-gray-500">
          Or reach out via email: Mejia.invest2@gmail.com
        </p>
      </motion.div>
    </div>
  );
}
